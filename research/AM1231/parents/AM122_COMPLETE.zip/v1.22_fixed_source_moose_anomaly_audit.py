#!/usr/bin/env python3
"""v1.22 fixed-source vacuum, anomaly repair, and moose obstruction audit.

This generator is deterministic and location-independent.  It advances the
verified v1.21 parent without changing its frozen transport constants.  The
new exact/benchmark results are:

* an explicit scalar-potential map for the fixed-X branch;
* a canonical homogeneous paired-field vacuum and source-on Hessian;
* a no-new-field Z24^R gravitational repair, R(Sigma)=17;
* a rank/nullity audit of global and gauged nearest-neighbour mooses;
* a gauge-invariance/amplification obstruction for a local gauged source.

The construction remains an exploratory EFT checkpoint, not an empirical
detection claim or a completed quantum-gravity UV model.
"""

from __future__ import annotations

import argparse
import csv
import hashlib
import itertools
import json
import math
import shutil
import zipfile
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np


VERSION = "v1.22"
TITLE = "fixed-source vacuum, anomaly repair, and moose obstruction audit"
EXPECTED_PARENT_SHA256 = "c251c2fed537b443831bbb4f17e5d85a1313e02b5b61c55869496089eb9c2e35"

M_MU_MEV = 105.6583755
M_TAU_MEV = 1776.93
EPSILON = math.sqrt(M_MU_MEV / M_TAU_MEV)
ETA = EPSILON**2
Q = 3
N = 30
LAMBDA_CW_GEV = 185.0
LAMBDA_DRIVE_GEV = 0.041659
F_ALPHA_GEV = 250.0
PURITY_LIMIT = 0.01

Q_SUPPRESSION = Q ** (-N)
LAMBDA_DRIVE_DIMLESS = (LAMBDA_DRIVE_GEV / LAMBDA_CW_GEV) ** 4
C_X = LAMBDA_DRIVE_DIMLESS / Q_SUPPRESSION
V_X_GEV = C_X * LAMBDA_CW_GEV
DRIVE4_GEV4 = LAMBDA_DRIVE_GEV**4
S_GEOM = sum(Q ** (-2 * j) for j in range(N + 1))

# The v1.22 benchmark explicitly chooses canonical Kahler normalization,
# homogeneous paired radii, and a radian alpha coordinate.
R_GEAR_GEV = F_ALPHA_GEV / (2 * math.sqrt(S_GEOM))
ZETA_30 = R_GEAR_GEV / LAMBDA_CW_GEV
P_CONDENSATE = C_X * ZETA_30
MU_LINK2_GEV2 = R_GEAR_GEV**4 / LAMBDA_CW_GEV**2
F_EFFECTIVE_GEV = (Q**N) * F_ALPHA_GEV
LOCAL_SOURCE4_GEV4 = C_X * LAMBDA_CW_GEV**4
LOCAL_SOURCE_CURVATURE_GEV2 = LOCAL_SOURCE4_GEV4 / (2 * R_GEAR_GEV**2)
ZERO_MODE_COMPONENT = Q ** (-N) / math.sqrt(2 * S_GEOM)
ZERO_MODE_MASS_GEV = math.sqrt(LOCAL_SOURCE_CURVATURE_GEV2) * ZERO_MODE_COMPONENT
KAPPA_LOCK = 4.0
PIN_MASS_GEV = LAMBDA_CW_GEV
Y_PIN_B = 0.1


def h_profile(u: float) -> float:
    return 16 * u / (3 + 21 * u**2 - 11 * u**4 + 3 * u**6)


def golden_max(fn, lo: float, hi: float) -> tuple[float, float]:
    ratio = (math.sqrt(5) - 1) / 2
    left = hi - ratio * (hi - lo)
    right = lo + ratio * (hi - lo)
    f_left, f_right = fn(left), fn(right)
    for _ in range(200):
        if f_left < f_right:
            lo, left, f_left = left, right, f_right
            right = lo + ratio * (hi - lo)
            f_right = fn(right)
        else:
            hi, right, f_right = right, left, f_left
            left = hi - ratio * (hi - lo)
            f_left = fn(left)
    point = (lo + hi) / 2
    return point, fn(point)


def stability_ratio(u: float) -> float:
    if abs(u - 1) < 1e-9 or h_profile(u) <= 1:
        return 0.0
    return 4 * C_X * (h_profile(u) - 1) / (ZETA_30**2 * (u * u - 1) ** 2)


_grid = np.linspace(0.0, 4.0, 20001)
_values = np.array([stability_ratio(float(u)) for u in _grid])
_imax = int(np.argmax(_values))
STABILITY_U, STABILITY_RATIO_MAX = golden_max(
    stability_ratio,
    float(_grid[max(0, _imax - 3)]),
    float(_grid[min(len(_grid) - 1, _imax + 3)]),
)
PIN_MASS_BOUND_RATIO = math.sqrt(STABILITY_RATIO_MAX)


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def write_csv(path: Path, rows: list[dict]) -> None:
    if not rows:
        raise ValueError(f"refusing to write empty table: {path}")
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def deterministic_zip(path: Path, files: list[Path]) -> None:
    timestamp = (2026, 8, 16, 12, 0, 0)
    with zipfile.ZipFile(path, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
        for source in sorted(files, key=lambda item: item.name):
            info = zipfile.ZipInfo(source.name, date_time=timestamp)
            info.compress_type = zipfile.ZIP_DEFLATED
            info.external_attr = 0o644 << 16
            archive.writestr(info, source.read_bytes())


def bisection(fn, target: float, lo: float, hi: float) -> float:
    for _ in range(180):
        mid = (lo + hi) / 2
        if fn(mid) < target:
            lo = mid
        else:
            hi = mid
    return (lo + hi) / 2


# ---------------------------------------------------------------------------
# Frozen v1.21 force envelope, replayed at the explicit v1.22 normalization.
# ---------------------------------------------------------------------------


def tower_sums_and_derivatives(delta: float) -> tuple[list[float], list[float]]:
    if not (0 <= delta < 1):
        return [math.inf] * 3, [math.inf] * 3
    den = (1 - delta**12) * (1 - ETA**3)
    den_p = -12 * delta**11 * (1 - ETA**3)
    nums = [
        delta**4 + ETA + delta**8 * ETA**2,
        delta**10 + delta**6 * ETA + delta**2 * ETA**2,
        1 + ETA * delta**8 + ETA**2 * delta**4,
    ]
    nums_p = [
        4 * delta**3 + 8 * delta**7 * ETA**2,
        10 * delta**9 + 6 * delta**5 * ETA + 2 * delta * ETA**2,
        8 * ETA * delta**7 + 4 * ETA**2 * delta**3,
    ]
    sums = [num / den for num in nums]
    derivs = [(num_p * den - num * den_p) / den**2 for num, num_p in zip(nums, nums_p)]
    return sums, derivs


def force_result(zeta: float) -> dict:
    delta = C_X * zeta
    sums, derivs = tower_sums_and_derivatives(delta)
    if not math.isfinite(sums[0]):
        return {"force_leading": math.inf, "force_endpoint_norm": math.inf, "rows": []}
    endpoint_norm = sums[2] + delta * derivs[2]
    total = 0.0
    rows = []
    for distance in range(1, N + 1):
        harmonic = Q**distance
        log_base = math.log(harmonic) + (harmonic - 1) * math.log(C_X)
        base = math.exp(log_base) if log_base > -745 else 0.0
        sector_index = 1 if distance % 2 else 0
        sector = "intermediate" if distance % 2 else "macro"
        dressed = sums[sector_index] + delta / harmonic * derivs[sector_index]
        contribution = base * dressed
        total += contribution
        rows.append(
            {
                "micro_distance": distance,
                "site": N - distance,
                "harmonic": harmonic,
                "sector": sector,
                "base_force_ratio": base,
                "dressed_force_sum": dressed,
                "force_over_leading_endpoint": contribution,
            }
        )
    for row in rows:
        row["fraction_of_unwanted_force"] = row["force_over_leading_endpoint"] / total
    return {
        "delta": delta,
        "force_leading": total,
        "force_endpoint_norm": total / endpoint_norm,
        "endpoint_norm": endpoint_norm,
        "rows": rows,
    }


ZETA_FORCE_BOUND = bisection(lambda z: force_result(z)["force_leading"], PURITY_LIMIT, 0.0, 1.5)
FORCE_BENCHMARK = force_result(ZETA_30)


def y_torque_sum(max_k: int = 120, max_l: int = 60) -> tuple[float, list[dict]]:
    """Absolute unit-soft Y torque in Lambda^4 units.

    The amplitude of each allowed P^k Y^l dressing is differentiated with
    respect to arg(Y), giving a factor l.  The finite bounds are far beyond
    numerical convergence because p<1 and eta<1.
    """

    totals = []
    grand = 0.0
    for distance in range(N + 1):
        harmonic = Q**distance
        bare_r = 2 if distance == 0 else (6 if distance % 2 else 18)
        if distance == 0:
            base = 1.0
        else:
            exponent = (harmonic - 1) * math.log(C_X)
            base = math.exp(exponent) if exponent > -745 else 0.0
        subtotal = 0.0
        for ell in range(max_l + 1):
            for k in range(max_k + 1):
                if (bare_r + 8 * ell + 2 * k - 2) % 24:
                    continue
                subtotal += C_X * base * ell * P_CONDENSATE**k * ETA**ell
        grand += subtotal
        totals.append(
            {
                "micro_distance": distance,
                "site": N - distance,
                "absolute_Y_torque_over_Lambda4": subtotal,
                "fraction_of_total": 0.0,
            }
        )
    for row in totals:
        row["fraction_of_total"] = row["absolute_Y_torque_over_Lambda4"] / grand
    return grand, totals


Y_TORQUE, Y_TORQUE_ROWS = y_torque_sum()
Y_RECOIL_BOUND = Y_TORQUE / (9 * Y_PIN_B)
Y_PHASE_MASS_GEV = 3 * math.sqrt(Y_PIN_B / (2 * ETA**2)) * LAMBDA_CW_GEV
NEAREST_MACRO_LOCAL_AMPLITUDE = ETA * C_X**9
Y_STIFFNESS_RATIO_KAPPA1 = NEAREST_MACRO_LOCAL_AMPLITUDE / (18 * ETA**6)


# ---------------------------------------------------------------------------
# Canonical paired-field source-off and source-on Hessians.
# ---------------------------------------------------------------------------


def constraint_hessians() -> dict:
    """Return the canonical constraint Jacobian and conditional Hessians.

    The 61x62 holomorphic Jacobian has 31 pair constraints and 30 local link
    constraints.  Exact SUSY leaves one complex axion/saxion modulus.  The
    phase-blind all-cell pin V_pb adds m_pin^2 to every radial eigenvalue but
    no phase mass.  The radial-orthogonalized H source adds only endpoint phase
    curvature because H'(1)=H''(1)=0.
    """

    size = 2 * (N + 1)
    jacobian = np.zeros((2 * N + 1, size), dtype=float)
    for j in range(N + 1):
        jacobian[j, j] = KAPPA_LOCK * R_GEAR_GEV
        jacobian[j, N + 1 + j] = KAPPA_LOCK * R_GEAR_GEV
    for j in range(N):
        row = N + 1 + j
        jacobian[row, N + 1 + j] = KAPPA_LOCK * R_GEAR_GEV**3 / LAMBDA_CW_GEV**2
        jacobian[row, j + 1] = Q * KAPPA_LOCK * R_GEAR_GEV**3 / LAMBDA_CW_GEV**2

    singular = np.linalg.svd(jacobian, compute_uv=False)
    phase = jacobian.T @ jacobian
    radial = phase + PIN_MASS_GEV**2 * np.eye(size)
    phase_values, phase_vectors = np.linalg.eigh(phase)
    radial_values = np.linalg.eigvalsh(radial)

    exact_zero = np.array(
        [Q ** (-j) for j in range(N + 1)] + [-Q ** (-j) for j in range(N + 1)],
        dtype=float,
    )
    exact_zero /= np.linalg.norm(exact_zero)
    null_residual = float(np.linalg.norm(jacobian @ exact_zero))

    # Heavy compliance is most transparently quoted at kappa=1.
    jacobian_unit = jacobian / KAPPA_LOCK
    phase_unit = jacobian_unit.T @ jacobian_unit
    unit_values, unit_vectors = np.linalg.eigh(phase_unit)
    inverse = np.where(unit_values > 1e-8, 1.0 / unit_values, 0.0)
    endpoint = np.zeros(size)
    endpoint[N] = 1.0
    endpoint_heavy = endpoint - exact_zero * float(exact_zero @ endpoint)
    compliance_unit = float(
        endpoint_heavy
        @ (unit_vectors @ (inverse * (unit_vectors.T @ endpoint_heavy)))
    )
    chi_unit = LOCAL_SOURCE_CURVATURE_GEV2 * compliance_unit
    chi = chi_unit / KAPPA_LOCK**2
    relaxation_factor = (1 + chi) / (1 - chi)

    source_min = phase.copy()
    source_min[N, N] += LOCAL_SOURCE_CURVATURE_GEV2
    source_top = phase.copy()
    source_top[N, N] -= LOCAL_SOURCE_CURVATURE_GEV2

    return {
        "jacobian": jacobian,
        "phase": phase,
        "radial": radial,
        "phase_values": phase_values,
        "radial_values": radial_values,
        "singular_values": singular,
        "phase_rank": int(np.linalg.matrix_rank(phase, tol=1e-5)),
        "radial_rank": int(np.linalg.matrix_rank(radial, tol=1e-5)),
        "phase_nullity": size - int(np.linalg.matrix_rank(phase, tol=1e-5)),
        "radial_nullity": size - int(np.linalg.matrix_rank(radial, tol=1e-5)),
        "null_residual": null_residual,
        "heavy_phase_gap_GeV": float(singular[-1]),
        "heavy_phase_max_GeV": float(singular[0]),
        "radial_gap_GeV": math.sqrt(float(radial_values[0])),
        "radial_heavy_min_GeV": math.sqrt(float(radial_values[1])),
        "radial_max_GeV": math.sqrt(float(radial_values[-1])),
        "source_curvature_GeV2": LOCAL_SOURCE_CURVATURE_GEV2,
        "compliance_unit_times_Lambda2": compliance_unit * LAMBDA_CW_GEV**2,
        "chi_unit": chi_unit,
        "chi": chi,
        "relaxation_factor": relaxation_factor,
        "kappa_tachyon_bound": math.sqrt(chi_unit),
        "kappa_10pct_bound": math.sqrt(chi_unit / 0.1),
        "zero_mass_bare_eV": ZERO_MODE_MASS_GEV * 1e9,
        "zero_mass_min_eV": ZERO_MODE_MASS_GEV * 1e9 / math.sqrt(1 + chi),
        "zero_tachyon_top_eV": ZERO_MODE_MASS_GEV * 1e9 / math.sqrt(1 - chi),
        "force_envelope_relaxed": FORCE_BENCHMARK["force_leading"] * relaxation_factor,
    }


HESSIAN = constraint_hessians()


def hessian_spectrum_rows() -> list[dict]:
    rows = []
    phase_values = HESSIAN["phase_values"]
    radial_values = HESSIAN["radial_values"]
    for index in range(len(phase_values)):
        p_value = 0.0 if index == 0 else max(0.0, float(phase_values[index]))
        r_value = max(0.0, float(radial_values[index]))
        rows.append(
            {
                "mode_index": index,
                "phase_mass2_GeV2_source_off": p_value,
                "phase_mass_GeV_source_off": math.sqrt(p_value),
                "radial_mass2_GeV2": r_value,
                "radial_mass_GeV": math.sqrt(r_value),
                "phase_role": "exact clockwork Goldstone" if index == 0 else "heavy phase gear",
            }
        )
    return rows


def vacuum_operator_rows() -> list[dict]:
    return [
        {
            "object": "canonical Kahler metric",
            "expression": "K=sum_j(|Phi_j|^2+|PhiBar_j|^2)",
            "zero_mode_dependence": "kinetic only",
            "status": "ADOPTED_BENCHMARK",
        },
        {
            "object": "paired radial constraints",
            "expression": "sum_j T_j(Phi_j PhiBar_j-r^2)",
            "zero_mode_dependence": "invariant",
            "status": "F_FLAT",
        },
        {
            "object": "nearest-neighbour links",
            "expression": "sum_j S_j(PhiBar_j Phi_(j+1)^3/Lambda^2-r^4/Lambda^2)",
            "zero_mode_dependence": "invariant; theta_j=3 theta_(j+1)",
            "status": "F_FLAT_LOCAL",
        },
        {
            "object": "cell-0-only lift plus simple source",
            "expression": "(|Phi_0|^2-|PhiBar_0|^2)^2/4 - b Re(X Phi_30)",
            "zero_mode_dependence": "local Hessian positive but explicit finite-cost runaway",
            "status": "FAIL_UNBOUNDED_THEOREM",
        },
        {
            "object": "all-cell phase-blind radial pins",
            "expression": "sum_j m_+^2(|Phi|^2+|PhiBar|^2-2r^2)^2/(8r^2)+m_-^2(|Phi|^2-|PhiBar|^2)^2/(8r^2)",
            "zero_mode_dependence": "phase blind; adds m_pin^2 to radial Hessian",
            "status": "CONDITIONAL_KAHLER_SUSY_BREAKING",
        },
        {
            "object": "retired P-phase constraint",
            "expression": "Z_X(P^4Y^2/Lambda^8-beta_P Lambda^2)",
            "zero_mode_dependence": "fourth-harmonic barrier",
            "status": "REMOVED",
        },
        {
            "object": "bounded radial-orthogonal fixed-X source",
            "expression": "V_0=-c_X Lambda^4 H(|Phi_30|/r) cos(theta_30+x_0+delta); H=16u/(3+21u^2-11u^4+3u^6)",
            "zero_mode_dependence": "theta_30=alpha/3^30",
            "status": "CONDITIONAL_BOUNDED_EXISTENCE_PROOF",
        },
    ]


def source_parameter_rows() -> list[dict]:
    return [
        {"quantity": "sum_j 3^(-2j)", "value": S_GEOM, "unit": "dimensionless", "status": "exact"},
        {"quantity": "homogeneous paired radius r", "value": R_GEAR_GEV, "unit": "GeV", "status": "derived benchmark"},
        {"quantity": "zeta_30=r/Lambda", "value": ZETA_30, "unit": "dimensionless", "status": "derived benchmark"},
        {"quantity": "p=c_X zeta_30", "value": P_CONDENSATE, "unit": "dimensionless", "status": "derived benchmark"},
        {"quantity": "fixed |X|", "value": V_X_GEV, "unit": "GeV", "status": "frozen parent"},
        {"quantity": "local source amplitude c_X Lambda^4", "value": LOCAL_SOURCE4_GEV4, "unit": "GeV^4", "status": "projects to frozen drive"},
        {"quantity": "projected drive c_X Lambda^4 3^-30", "value": LOCAL_SOURCE4_GEV4 * Q**(-N), "unit": "GeV^4", "status": "equals Lambda_drive^4"},
        {"quantity": "H(1)", "value": h_profile(1.0), "unit": "dimensionless", "status": "exactly one"},
        {"quantity": "leading-source global stability max ratio", "value": STABILITY_RATIO_MAX, "unit": "(m_pin/Lambda)^2", "status": "derived sufficient bound for bounded endpoint source"},
        {"quantity": "minimum pin mass ratio for leading source", "value": PIN_MASS_BOUND_RATIO, "unit": "m_pin/Lambda", "status": "benchmark m_pin/Lambda=1 passes leading-source bound"},
        {"quantity": "effective endpoint period 3^30 F_alpha", "value": F_EFFECTIVE_GEV, "unit": "GeV", "status": "derived benchmark"},
        {"quantity": "bare leading-cosine zero-mode mass", "value": ZERO_MODE_MASS_GEV, "unit": "GeV", "status": "before heavy-mode compliance"},
        {"quantity": "heavy phase gap", "value": HESSIAN["heavy_phase_gap_GeV"], "unit": "GeV", "status": "positive"},
        {"quantity": "radial gap", "value": HESSIAN["radial_gap_GeV"], "unit": "GeV", "status": "positive"},
        {"quantity": "heavy compliance chi at kappa=4", "value": HESSIAN["chi"], "unit": "dimensionless", "status": "below 10pct"},
        {"quantity": "profile relaxation force factor", "value": HESSIAN["relaxation_factor"], "unit": "dimensionless", "status": "conservative"},
        {"quantity": "Y torque", "value": Y_TORQUE, "unit": "Lambda^4", "status": "W_Y alone fails"},
        {"quantity": "Y phase recoil with b_Y=0.1", "value": Y_RECOIL_BOUND, "unit": "radian", "status": "conditional pass"},
        {"quantity": "Y phase pin mass", "value": Y_PHASE_MASS_GEV, "unit": "GeV", "status": "below 4pi Lambda"},
        {"quantity": "unwanted force envelope", "value": FORCE_BENCHMARK["force_leading"], "unit": "endpoint force", "status": "pass 1pct"},
        {"quantity": "profile-relaxation stress proxy", "value": HESSIAN["force_envelope_relaxed"], "unit": "endpoint force", "status": "pass 1pct conditional; not a solved full-tower evolution"},
    ]


def source_stability_rows() -> list[dict]:
    points = [0.0, 1 / math.sqrt(5), STABILITY_U, 1.0, 2.0, 10.0]
    return [
        {
            "u_absPhi30_over_r": u,
            "H_u": h_profile(u),
            "stability_ratio": stability_ratio(u),
            "benchmark_mpin2_over_Lambda2": 1.0,
            "passes_sufficient_bound": 1.0 >= stability_ratio(u),
        }
        for u in points
    ]


def rejected_runaway_rows() -> list[dict]:
    rows = []
    zeta = ZETA_30
    for exponent in range(9):
        ratio = 10.0**exponent
        x30 = zeta * ratio
        y30 = zeta**2 / x30
        y29 = zeta**4 / x30**3
        x29 = zeta
        t30 = x30 * y30 - zeta**2
        link29 = y29 * x30**3 - zeta**4
        t29 = x29 * y29 - zeta**2
        finite_f = KAPPA_LOCK**2 * (t30**2 + link29**2 + t29**2)
        simple_source = -C_X * x30
        rows.append(
            {
                "log10_R_over_r": exponent,
                "Phi30_over_Lambda": x30,
                "PhiBar30_over_Lambda": y30,
                "PhiBar29_over_Lambda": y29,
                "T30_residual": t30,
                "link29_residual": link29,
                "T29_residual": t29,
                "finite_F_proxy_over_Lambda4": finite_f,
                "simple_source_over_Lambda4": simple_source,
                "total_proxy_over_Lambda4": finite_f + simple_source,
            }
        )
    return rows


def fixed_x_rows() -> list[dict]:
    b_x = 1.0
    mass = math.sqrt(72 * b_x) * LAMBDA_CW_GEV / C_X
    recoil = C_X / (144 * b_x)
    return [
        {
            "branch": "strict external/pinned phase x0",
            "pin_coefficient": "not dynamical",
            "phase_mass_GeV": "not applicable",
            "max_recoil_radian": 0,
            "induced_second_harmonic_force": 0,
            "vacuum_branches": "spurionic",
            "status": "CONDITIONAL_EFT",
        },
        {
            "branch": "dynamical V_Xpin=b_X Lambda^4[1-cos(12x)]",
            "pin_coefficient": b_x,
            "phase_mass_GeV": mass,
            "max_recoil_radian": recoil,
            "induced_second_harmonic_force": recoil / 2,
            "vacuum_branches": 12,
            "status": "WATCH_REQUIRES_SEQUESTERING_AND_WALL_SOLUTION",
        },
    ]


# ---------------------------------------------------------------------------
# Minimal no-new-field anomaly repair: R(Sigma)=17.
# ---------------------------------------------------------------------------


def field(name: str, q_cw: int, r24: int, role: str, site: str) -> dict:
    return {"name": name, "Q": q_cw, "R": r24 % 24, "role": role, "site": site}


def full_fields(sigma_r: int) -> list[dict]:
    fields = [
        field("X", -1, 2, "light", "bulk"),
        field("Xbar", 1, 0, "light", "30"),
        field("Y", 0, 8, "light", "bulk"),
        field("chi", 0, 0, "light", "30"),
        field("S_Y", 0, 2, "stabilizer", "30"),
        field("Psi+", 1, 5, "spectator", "30"),
        field("Psi-", -1, 5, "spectator", "30"),
        field("Sigma", 0, sigma_r, "spectator", "30"),
    ]
    for j in range(N + 1):
        charge = Q ** (N - j)
        fields.append(field(f"Phi_{j}", charge, 0, "gear", str(j)))
        fields.append(field(f"PhiBar_{j}", -charge, 0, "gear", str(j)))
    for j in range(N):
        fields.append(field(f"S_{j}", 0, 2, "stabilizer", f"edge:{j}-{j+1}"))
    for j in range(N + 1):
        fields.append(field(f"T_{j}", 0, 2, "stabilizer", str(j)))
    for a in range(1, 9):
        charge = 9 - a
        r_a = -2 * (a - 1)
        fields.append(field(f"A_{a}", -charge, r_a, "messenger", "28"))
        fields.append(field(f"B_{a}", charge, 2 - r_a, "messenger", "28"))
    fields.extend(
        [
            field("Z_X", 0, 2, "retired_constraint_pair", "30"),
            field("C_X", 0, 0, "retired_constraint_pair", "30"),
            field("Z_A", 0, 2, "conditional_GS_pair", "30"),
            field("C_A", 0, 0, "conditional_GS_pair", "30"),
        ]
    )
    return fields


Z2H_ODD = {"Xbar", "C_X", "C_A", "Sigma", "chi"}


def sigma_candidate_rows() -> list[dict]:
    rows = []
    old_fermion = 4 - 1
    for r_value in range(24):
        fermion = r_value - 1
        delta = (fermion - old_fermion) % 12
        y2_mass = (2 * r_value + 2 * 8) % 24 == 2
        sigma_terms = []
        for degree in (1, 2, 3):
            for combo in itertools.combinations_with_replacement(full_fields(r_value), degree):
                names = tuple(sorted(item["name"] for item in combo))
                if "Sigma" not in names:
                    continue
                if sum(item["Q"] for item in combo) != 0:
                    continue
                if sum(item["R"] for item in combo) % 24 != 2:
                    continue
                parity_allowed = sum(name in Z2H_ODD for name in names) % 2 == 0
                if parity_allowed:
                    sigma_terms.append(" ".join(names))
        rows.append(
            {
                "R_Sigma": r_value,
                "fermion_R": fermion % 24,
                "delta_A0_mod12_vs_R4": delta,
                "repairs_plus1_residue": delta == 1,
                "Y2_Sigma2_mass_allowed": y2_mass,
                "P_Y_linear_tadpole_possible": r_value % 2 == 0,
                "renormalizable_Sigma_terms_after_Z2H": len(sigma_terms),
                "terms": ";".join(sigma_terms) or "none",
                "decision": "PREFERRED" if r_value == 17 else ("ALTERNATE" if r_value == 5 else "REJECT"),
            }
        )
    return rows


def anomaly_ledger_rows() -> list[dict]:
    return [
        {"component": "visible MSSM including gravitino and MSSM gauginos", "raw_A0": 283, "A0_mod12": 7, "delta_mixed_gauge_from_sigma_repair": 0, "comment": "frozen Z24R assignment"},
        {"component": "GS axino/dilatino", "raw_A0": -1, "A0_mod12": 11, "delta_mixed_gauge_from_sigma_repair": 0, "comment": "fermion R=-1"},
        {"component": "fixed/global hidden excluding Sigma and absent CW gaugino", "raw_A0": 14, "A0_mod12": 2, "delta_mixed_gauge_from_sigma_repair": 0, "comment": "X/Xbar retained or removed only as a net-zero pair"},
        {"component": "Sigma with R=17", "raw_A0": 16, "A0_mod12": 4, "delta_mixed_gauge_from_sigma_repair": 0, "comment": "old R=4 fermion contributed 3; change is +1 mod12"},
        {"component": "total after repair", "raw_A0": 312, "A0_mod12": 0, "delta_mixed_gauge_from_sigma_repair": 0, "comment": "283-1+14+16=312=0 mod12"},
    ]


def anomaly_repair_rows() -> list[dict]:
    mixed_raw = -2 * sum(9**k for k in range(N + 1)) + 8
    return [
        {
            "check": "gravitational residue",
            "value": (7 + 11 + 5 + 1) % 12,
            "target": 0,
            "status": "PASS_STANDARD_LINEAR_CONGRUENCE",
        },
        {
            "check": "hidden U1_CW^2-Z24R diagnostic",
            "value": mixed_raw % 12,
            "target": 6,
            "status": "PASS_UNCHANGED_DIAGNOSTIC_GLOBAL_BRANCH",
        },
        {
            "check": "Y^2 Sigma^2 R charge",
            "value": (2 * 8 + 2 * 17) % 24,
            "target": 2,
            "status": "PASS",
        },
        {
            "check": "m_Sigma/Lambda at unit lambda",
            "value": ETA**2,
            "target": ">0",
            "status": "PASS",
        },
        {
            "check": "m_Sigma at unit lambda",
            "value": ETA**2 * LAMBDA_CW_GEV,
            "target": ">0 GeV",
            "status": "PASS",
        },
        {
            "check": "P^k Y^l Sigma tadpoles",
            "value": 0,
            "target": 0,
            "status": "PASS_ALL_ORDERS_PARITY_THEOREM",
        },
        {
            "check": "new renormalizable Sigma couplings after Z2H",
            "value": 0,
            "target": 0,
            "status": "PASS_EXHAUSTIVE_LISTED_SPECTRUM",
        },
        {
            "check": "nonlinear/cubic discrete anomalies",
            "value": "not imposed",
            "target": "UV definition",
            "status": "WATCH",
        },
        {
            "check": "P-dressed Sigma mass thresholds",
            "value": "P^4 Y and P^8 allowed",
            "target": "Y-only spectator locality or explicit loop bound",
            "status": "WATCH",
        },
    ]


# ---------------------------------------------------------------------------
# Messenger locality replay with the repaired Sigma assignment.
# ---------------------------------------------------------------------------


def intended_messenger_terms() -> set[tuple[str, ...]]:
    terms = {tuple(sorted(("X", "Phi_28", "A_1")))}
    terms |= {tuple(sorted(("X", f"B_{a}", f"A_{a+1}"))) for a in range(1, 8)}
    terms.add(tuple(sorted(("X", "Y", "B_8"))))
    terms |= {tuple(sorted((f"A_{a}", f"B_{a}"))) for a in range(1, 9)}
    return terms


def messenger_locality_rows() -> list[dict]:
    fields = full_fields(17)
    intended = intended_messenger_terms()
    rows = []
    for degree in (2, 3):
        for combo in itertools.combinations_with_replacement(fields, degree):
            if not any(item["role"] == "messenger" for item in combo):
                continue
            if sum(item["Q"] for item in combo) != 0:
                continue
            if sum(item["R"] for item in combo) % 24 != 2:
                continue
            names = tuple(sorted(item["name"] for item in combo))
            parity_allowed = sum(name in Z2H_ODD for name in names) % 2 == 0
            nonbulk_sites = sorted(
                {
                    item["site"]
                    for item in combo
                    if item["site"] != "bulk" and item["role"] != "messenger"
                }
            )
            locality_allowed = all(site == "28" for site in nonbulk_sites)
            rows.append(
                {
                    "degree": degree,
                    "monomial": " ".join(names),
                    "intended": names in intended,
                    "Z2H_allowed": parity_allowed,
                    "nonbulk_light_sites": ";".join(nonbulk_sites) or "none",
                    "cell28_locality_allowed": locality_allowed,
                    "allowed_after_Z2H_and_locality": parity_allowed and locality_allowed,
                }
            )
    return sorted(rows, key=lambda row: (not row["intended"], row["degree"], row["monomial"]))


# ---------------------------------------------------------------------------
# Product/moose rank, gauge-invariance, and perturbativity audit.
# ---------------------------------------------------------------------------


def moose_matrices() -> dict:
    link = np.zeros((N, N + 1), dtype=float)
    for edge in range(N):
        link[edge, edge] = 1.0
        link[edge, edge + 1] = -float(Q)
    rank = int(np.linalg.matrix_rank(link))
    null = np.array([Q ** (-j) for j in range(N + 1)], dtype=float)
    null /= np.linalg.norm(null)

    # Add a dynamical endpoint compensator X with charge +q under the last
    # product factor so X Phi_N is locally gauge invariant.
    compensated = np.zeros((N, N + 2), dtype=float)
    compensated[:, : N + 1] = link
    compensated[N - 1, N + 1] = float(Q)
    local_source = np.zeros(N + 2)
    local_source[N] = 1.0
    local_source[N + 1] = 1.0

    integer_kernel = [Q ** (N - j) for j in range(N + 1)]
    invariant_degree = sum(integer_kernel)
    f_phi = math.sqrt(2) * R_GEAR_GEV
    f_x = math.sqrt(2) * V_X_GEV
    reduced_local_scale = 1 / math.sqrt(1 / f_phi**2 + 1 / f_x**2)
    return {
        "link": link,
        "rank": rank,
        "nullity": N + 1 - rank,
        "null": null,
        "residual": float(np.linalg.norm(link @ null)),
        "endpoint_overlap": float(abs(null[-1])),
        "integer_kernel": integer_kernel,
        "invariant_degree": invariant_degree,
        "compensated": compensated,
        "compensated_rank": int(np.linalg.matrix_rank(compensated)),
        "compensated_nullity": N + 2 - int(np.linalg.matrix_rank(compensated)),
        "local_source_residual": float(np.linalg.norm(compensated @ local_source)),
        "local_source_norm": float(np.linalg.norm(local_source)),
        "reduced_local_scale_GeV": reduced_local_scale,
    }


MOOSE = moose_matrices()


def moose_branch_rows() -> list[dict]:
    return [
        {
            "branch": "global scalar moose + fixed X",
            "matrix_rank": MOOSE["rank"],
            "physical_phase_nullity": MOOSE["nullity"],
            "endpoint_source": "allowed as global spurion",
            "effective_scale_GeV": F_EFFECTIVE_GEV,
            "status": "CONDITIONAL_PASS_EFT",
            "reason": "one uneaten Goldstone; local cell/edge interactions; exact global symmetry remains UV-sensitive",
        },
        {
            "branch": "gauged product + fixed charged X background",
            "matrix_rank": MOOSE["rank"],
            "physical_phase_nullity": MOOSE["nullity"],
            "endpoint_source": "not a gauge-invariant fixed background",
            "effective_scale_GeV": "not defined",
            "status": "FAIL_GAUGE_INVARIANCE",
            "reason": "a gauge-charged source must be dynamical or represented by a gauge-invariant nonlocal operator",
        },
        {
            "branch": "gauged product + dynamical endpoint compensator",
            "matrix_rank": MOOSE["compensated_rank"],
            "physical_phase_nullity": MOOSE["compensated_nullity"],
            "endpoint_source": "X Phi_30 is gauge invariant",
            "effective_scale_GeV": MOOSE["reduced_local_scale_GeV"],
            "status": "FAIL_AMPLIFICATION",
            "reason": "the source exponent is itself a localized kernel vector; one other mode remains undriven",
        },
        {
            "branch": "gauged product + gear-only holomorphic invariant",
            "matrix_rank": MOOSE["rank"],
            "physical_phase_nullity": MOOSE["nullity"],
            "endpoint_source": f"first phase-sensitive positive-exponent gear-only invariant has degree {MOOSE['invariant_degree']}",
            "effective_scale_GeV": F_EFFECTIVE_GEV,
            "status": "FAIL_PERTURBATIVE_SOURCE",
            "reason": "degree-(3^31-1)/2 phase-sensitive gear polynomial is not the inherited endpoint operator; radial degree-two invariants are irrelevant",
        },
    ]


def moose_matrix_rows() -> list[dict]:
    rows = []
    for edge in range(N):
        rows.append(
            {
                "edge": edge,
                "left_site": edge,
                "left_charge": 1,
                "right_site": edge + 1,
                "right_charge": -Q,
                "rank_total": MOOSE["rank"],
                "nullity_total": MOOSE["nullity"],
                "kernel_residual": MOOSE["residual"],
            }
        )
    return rows


def perturbativity_rows() -> list[dict]:
    reduced_planck = 2.435e18
    log_range = math.log(reduced_planck / LAMBDA_CW_GEV)
    rows = []
    cases = [
        ("ordinary edge", 2 * (1 + Q**2), "paired adjacent gears only"),
        (
            "forced gauged transfer of endpoint plus 17 messenger vertices",
            5168,
            "includes Q_29(A_a)=-3a and Q_29(Y)=-27; old Y^3 stabilizer then fails gauge invariance",
        ),
    ]
    for name, beta, comment in cases:
        g_max = math.sqrt(8 * math.pi**2 / (beta * log_range))
        g_max_decade = math.sqrt(8 * math.pi**2 / (beta * math.log(10)))
        pole_ratio_g03 = math.exp(8 * math.pi**2 / (beta * 0.3**2))
        rows.append(
            {
                "factor": name,
                "one_loop_b": beta,
                "g_max_for_Landau_pole_above_reduced_Planck": g_max,
                "g_max_for_one_decade": g_max_decade,
                "Landau_pole_over_Lambda_at_g0.3": pole_ratio_g03,
                "comment": comment,
                "status": "PASS_AT_g0.3" if 0.3 < g_max else "REQUIRES_SMALL_LOCAL_COUPLING_OR_DISTRIBUTED_MESSENGERS",
            }
        )
    return rows


def locality_contract_rows() -> list[dict]:
    remaining = PURITY_LIMIT - HESSIAN["force_envelope_relaxed"]
    return [
        {"vertex": "PhiBar_j Phi_(j+1)^3", "support": "nearest edge j-(j+1)", "decision": "ALLOW"},
        {"vertex": "X Phi_28 A_1 and messenger chain", "support": "cell 28 with bulk/source profile", "decision": "ALLOW"},
        {"vertex": "B_1 PhiBar_28 Phi_30", "support": "cells 28 and 30; skips cell 29", "decision": "FORBID_BY_LOCALITY"},
        {"vertex": "X Phi_30 source", "support": "endpoint cell 30", "decision": "ALLOW_GLOBAL_BRANCH_ONLY"},
        {"vertex": "bridging mediator/link-dressed shortcut", "support": "UV dependent", "decision": "WATCH"},
        {"vertex": "nonlocal shortcut amplitude epsilon_sc", "support": "two-edge propagation", "decision": f"REQUIRE < {remaining:.12g}"},
        {"vertex": "two-edge hopping factor", "support": "kappa_sc~r_hop^2", "decision": f"REQUIRE r_hop < {math.sqrt(remaining):.12g}"},
        {"vertex": "geometric gap", "support": "kappa_sc~exp(-2 M_gap a)", "decision": f"REQUIRE M_gap a > {-0.5*math.log(remaining):.12g}"},
    ]


def sigma_mass_tower_rows() -> list[dict]:
    rows = []
    for k, ell, name in [
        (0, 2, "Y^2 Sigma^2"),
        (4, 1, "P^4 Y Sigma^2"),
        (8, 0, "P^8 Sigma^2"),
    ]:
        rows.append(
            {
                "operator": name,
                "P_power": k,
                "Y_power": ell,
                "R_total_mod24": (2 * 17 + 2 * k + 8 * ell) % 24,
                "canonical_mass_factor": P_CONDENSATE**k * ETA**ell,
                "unit_zeta_mass_factor": C_X**k * ETA**ell,
                "P_endpoint_phase_dependent": k > 0,
                "tower_scope": "leading representative; higher members recur under P^12 and/or Y^3 dressing",
                "potential_condition": "a Sigma=0 phase potential requires operator interference and/or soft/Coleman-Weinberg effects",
                "decision": "KEEP_Y_ONLY" if k == 0 else "FORBID_BY_SPECTATOR_LOCALITY_OR_BOUND_THRESHOLD",
            }
        )
    return rows


def moose_r_anomaly_rows() -> list[dict]:
    return [
        {
            "matrix_class": "diagonal",
            "raw_value": -2 * (1 + Q**2),
            "mod12": (-2 * (1 + Q**2)) % 12,
            "multiplicity": N,
            "status": "NONZERO",
        },
        {
            "matrix_class": "nearest off-diagonal",
            "raw_value": 2 * Q,
            "mod12": (2 * Q) % 12,
            "multiplicity": 2 * (N - 1),
            "status": "NONDIAGONAL_GS_REQUIRED",
        },
        {
            "matrix_class": "all other entries",
            "raw_value": 0,
            "mod12": 0,
            "multiplicity": N * N - N - 2 * (N - 1),
            "status": "ZERO",
        },
    ]


def parent_verification_rows(parent: Path | None) -> list[dict]:
    if parent is None:
        return [{"check": "parent bundle supplied", "value": False, "status": "NOT_REPLAYED"}]
    actual = sha256(parent)
    rows = [
        {
            "check": "v1.21 bundle SHA256",
            "value": actual,
            "expected": EXPECTED_PARENT_SHA256,
            "status": "PASS" if actual == EXPECTED_PARENT_SHA256 else "FAIL",
        }
    ]
    if actual != EXPECTED_PARENT_SHA256:
        return rows
    with zipfile.ZipFile(parent, "r") as archive:
        bad = archive.testzip()
        members = archive.namelist()
        ledger = archive.read("v1.21_SHA256.txt").decode("utf-8").splitlines()
        ledger_failures = 0
        for line in ledger:
            expected, name = line.split("  ", 1)
            if hashlib.sha256(archive.read(name)).hexdigest() != expected:
                ledger_failures += 1
        rows.extend(
            [
                {"check": "ZIP integrity", "value": bad or "none", "expected": "none", "status": "PASS" if bad is None else "FAIL"},
                {"check": "member count", "value": len(members), "expected": 23, "status": "PASS" if len(members) == 23 else "FAIL"},
                {"check": "internal SHA ledger failures", "value": ledger_failures, "expected": 0, "status": "PASS" if ledger_failures == 0 else "FAIL"},
            ]
        )
    return rows


def gate_rows(messenger: list[dict]) -> list[dict]:
    intended_after = sum(row["intended"] and row["allowed_after_Z2H_and_locality"] for row in messenger)
    unintended_after = sum((not row["intended"]) and row["allowed_after_Z2H_and_locality"] for row in messenger)
    return [
        {"gate_id": "COERCIVE-CELL0-01", "status": "FAIL_THEOREM", "value": "-infinity", "criterion": "cell-0-only radial lift plus simple endpoint source must be bounded"},
        {"gate_id": "SUSY-SAXION-01", "status": "FAIL_THEOREM", "value": 1, "criterion": "61 holomorphic constraints cannot lift the one complex modulus among 62 gear chirals"},
        {"gate_id": "DRIVE-MAP-01", "status": "CONDITIONAL_PASS", "value": LOCAL_SOURCE4_GEV4, "criterion": "leading bounded H(u) scalar-potential source projects to inherited drive; full tower needs analogous maps"},
        {"gate_id": "VAC-PPHASE-01", "status": "PASS_REMOVAL", "value": 0, "criterion": "P^4Y^2 hard phase constraint absent"},
        {"gate_id": "H-SOURCE-01", "status": "BOUNDED_CONDITIONAL", "value": h_profile(1.0), "criterion": "leading-source H is bounded with H(1)=1 and first two derivatives zero"},
        {"gate_id": "RADIAL-GLOBAL-01", "status": "PASS_CONDITIONAL", "value": PIN_MASS_BOUND_RATIO, "criterion": "m_pin/Lambda=1 exceeds sufficient leading-source global-stability bound"},
        {"gate_id": "VAC-HESSIAN-01", "status": "PASS_BENCHMARK", "value": HESSIAN["heavy_phase_gap_GeV"], "criterion": "one phase zero mode source-off and every other phase/radial mode positive"},
        {"gate_id": "PHASE-HEAVY-01", "status": "PASS_CONDITIONAL", "value": HESSIAN["kappa_tachyon_bound"], "criterion": "kappa=4 exceeds heavy-mode tachyon bound"},
        {"gate_id": "PROFILE-10PCT-01", "status": "PASS_CONDITIONAL", "value": HESSIAN["kappa_10pct_bound"], "criterion": "kappa=4 keeps heavy compliance below 10pct"},
        {"gate_id": "Y-RIGID-01", "status": "FAIL", "value": Y_STIFFNESS_RATIO_KAPPA1, "criterion": "original W_Y stiffness alone must dominate nearest macro soft harmonic"},
        {"gate_id": "Y-PIN-01", "status": "CONDITIONAL_PASS", "value": Y_RECOIL_BOUND, "criterion": "b_Y=0.1 phase pin keeps Y recoil below 0.001 rad"},
        {"gate_id": "NORM-MAP-01", "status": "PASS_CONDITIONAL_MODEL", "value": ZETA_30, "criterion": "canonical homogeneous paired radian benchmark explicitly chosen"},
        {"gate_id": "FORCE-PURITY-01", "status": "PASS_CONDITIONAL_STRESS_PROXY", "value": HESSIAN["force_envelope_relaxed"], "criterion": "exact frozen rigid force times conservative compliance stress factor <1%; full source-on tower not solved"},
        {"gate_id": "ANOM-GRAV-01", "status": "PASS_STANDARD_LINEAR", "value": 0, "criterion": "A0 total =0 mod12 after R(Sigma)=17"},
        {"gate_id": "ANOM-NONLINEAR-01", "status": "WATCH", "value": "", "criterion": "UV-sensitive nonlinear/cubic discrete anomaly conditions not claimed"},
        {"gate_id": "ANOM-SIGMA-THRESHOLD-01", "status": "WATCH", "value": P_CONDENSATE**4 * ETA, "criterion": "P-dressed Sigma masses require Y-only spectator locality or loop bound"},
        {"gate_id": "MESS-LOCALITY-01", "status": "CONDITIONAL_PASS", "value": f"{intended_after}+{unintended_after}", "criterion": "cell/edge locality plus Z2H gives 17 intended and zero unintended"},
        {"gate_id": "MOOSE-GLOBAL-01", "status": "CONDITIONAL_PASS_EFT", "value": MOOSE["nullity"], "criterion": "local global moose leaves one rolling mode"},
        {"gate_id": "MOOSE-GAUGE-FIXED-01", "status": "FAIL", "value": 0, "criterion": "fixed charged endpoint source must be gauge invariant"},
        {"gate_id": "MOOSE-GAUGE-DYNX-01", "status": "FAIL_AMPLIFICATION", "value": MOOSE["reduced_local_scale_GeV"], "criterion": "dynamical compensator must retain 3^30 effective period"},
        {"gate_id": "FIXED-X-NATURALNESS-01", "status": "OPEN", "value": "external spurion", "criterion": "dynamical pin would add walls and sequestering requirements"},
        {"gate_id": "R-SOFT-ALIGNMENT-01", "status": "OPEN", "value": -2, "criterion": "scalar source coefficient needs aligned/sequestered R=-2 breaking"},
        {"gate_id": "COSMOLOGY-01", "status": "OPEN", "value": "", "criterion": "thermal locking, R walls, odd relics, and GS modulus history"},
        {"gate_id": "PUBLICATION-01", "status": "HOLD", "value": "", "criterion": "gauged/nonlocal source and cosmology remain unresolved"},
    ]


def markdown_table(rows: list[dict], columns: list[str], formats: dict[str, str] | None = None) -> str:
    formats = formats or {}
    lines = ["| " + " | ".join(columns) + " |", "| " + " | ".join(["---"] * len(columns)) + " |"]
    for row in rows:
        values = []
        for column in columns:
            value = row[column]
            if column in formats and isinstance(value, (int, float)):
                value = format(value, formats[column])
            values.append(str(value).replace("|", "\\|"))
        lines.append("| " + " | ".join(values) + " |")
    return "\n".join(lines)


def build_note(gates: list[dict], anomaly: list[dict], branches: list[dict], perturbativity: list[dict]) -> str:
    gate_table = markdown_table(gates, ["gate_id", "status", "value", "criterion"])
    anomaly_table = markdown_table(anomaly, ["component", "raw_A0", "A0_mod12", "delta_mixed_gauge_from_sigma_repair", "comment"])
    branch_table = markdown_table(branches, ["branch", "physical_phase_nullity", "endpoint_source", "effective_scale_GeV", "status"])
    perturb_table = markdown_table(perturbativity, ["factor", "one_loop_b", "g_max_for_Landau_pole_above_reduced_Planck", "status"], {"g_max_for_Landau_pole_above_reduced_Planck": ".6g"})
    return f"""# v1.22 — fixed-source vacuum, anomaly repair, and moose obstruction audit

## Executive decision

v1.22 establishes a **conditional fixed-source EFT existence proof**, not a
UV completion.  The red-team rejected the naive cell-0/simple-A construction
as unbounded, then replaced it with an all-cell phase-blind Kähler/soft pin and
a bounded radial-orthogonalized source.  It also repairs the reopened standard
gravitational `Z_24^R` congruence without adding a field:

```text
R(Sigma): 4 -> 17 mod 24.
```

For the canonical paired/radian benchmark and `kappa_T=kappa_S=4`:

```text
zeta_30                              = {ZETA_30:.12f}
p=c_X zeta_30                       = {P_CONDENSATE:.12f}
exact frozen rigid force            = {FORCE_BENCHMARK['force_leading']:.12f}
profile-relaxation stress proxy     = {HESSIAN['force_envelope_relaxed']:.12f}
phase/stabilizer mass band          = {HESSIAN['heavy_phase_gap_GeV']:.6f}--{HESSIAN['heavy_phase_max_GeV']:.6f} GeV
clockwork saxion mass               = {HESSIAN['radial_gap_GeV']:.6f} GeV
```

The conservative compliance stress proxy is **{100*HESSIAN['force_envelope_relaxed']:.4f}%**,
below the inherited 1% gate.  It is not a solved time-dependent, full-tower
source-on force.  The product/moose audit nevertheless proves that
a fully gauged local version cannot retain the inherited endpoint source:
fixed charged `X` violates gauge invariance, while dynamical `X` drives a local
mode with scale `{MOOSE['reduced_local_scale_GeV']:.6f} GeV`, not
`{F_EFFECTIVE_GEV:.6e} GeV`.  Publication remains on hold.

## 1. Two vacuum theorems before the repair

The invariant F-lock superpotential is

```text
W_inv = sum_j kappa_T T_j(Phi_j PhiBar_j-r^2)
      + sum_(j=0)^29 kappa_S S_j(PhiBar_j Phi_(j+1)^3/Lambda^2-r^4/Lambda^2)
      + kappa_Y S_Y(Y^3/Lambda-eta^3 Lambda^2).
```

There are 62 gear chirals and only 61 independent holomorphic gear
constraints.  Exact SUSY therefore leaves one complex chiral modulus: axion
plus saxion.  Gauging it would lift/eat the desired axion, so phase-blind
saxion stabilization must use SUSY breaking, Kähler dynamics, or conditional
strong dynamics.

The earlier cell-0 quartic does not bound a simple endpoint A-term.  Set

```text
Phi_30=R, PhiBar_30=r^2/R,
PhiBar_29=r^4/R^3, Phi_29=r,
```

and keep cells 0--28 homogeneous.  The cell-30 radial and link-29 constraints
remain exact; only one radial residual approaches a finite constant, while
`-b Re(X Phi_30)` tends to minus infinity.  A positive local Hessian was not a
global boundedness proof.

## 2. Bounded phase-blind benchmark

Delete the v1.20 `Z_X(P^4Y^2-constant)` phase constraint and use

```text
V_pb=sum_j [
 m_+^2 (|Phi_j|^2+|PhiBar_j|^2-2r^2)^2/(8r^2)
+m_-^2 (|Phi_j|^2-|PhiBar_j|^2)^2/(8r^2)].
```

For `m_+=m_-=m`, it adds `m^2` to every gear-radial Hessian eigenvalue while
leaving every phase untouched.  It can descend from SUSY-breaking Kähler
operators, but is not a strict Girardello--Grisaru soft term.

Use the bounded source

```text
V_0=-A(t) H(|Phi_30|/r) cos(theta_30+x_0+delta(t)),
H(u)=16u/(3+21u^2-11u^4+3u^6).
```

The denominator is positive for `u>=0`, and

```text
H(1)=1, H'(1)=H''(1)=0.
```

Thus the homogeneous radius is exactly source-on stationary and the source
adds no radial tadpole, radial Hessian shift, or radial/phase cross block.
The source normalization is

```text
A_peak=c_X Lambda^4={LOCAL_SOURCE4_GEV4:.12e} GeV^4,
A_peak 3^-30={LOCAL_SOURCE4_GEV4*Q**(-N):.12e} GeV^4
             =(41.659 MeV)^4.
```

The exact sufficient stability bound for this leading bounded endpoint source is

```text
(m/Lambda)^2 >= {STABILITY_RATIO_MAX:.12f},
m/Lambda       > {PIN_MASS_BOUND_RATIO:.12f}.
```

The benchmark `m=Lambda` passes that leading-source bound.  Every retained
P/Y/site soft harmonic still needs an analogous radial-orthogonal map and a
combined bound.  This rational form factor is an engineered EFT existence
proof, not a derived polynomial UV operator.

Canonical paired kinetics give

```text
F_alpha^2=4r^2 sum_(j=0)^30 3^(-2j),
r={R_GEAR_GEV:.12f} GeV, zeta_30={ZETA_30:.12f}.
```

The 61x62 constraint Jacobian has a single null vector proportional to
`(3^-j,-3^-j)`.  At `kappa=4`, the heavy compliance is
`chi={HESSIAN['chi']:.9f}`; the tachyon-avoidance and 10% rigidity conditions
are respectively

```text
kappa>{HESSIAN['kappa_tachyon_bound']:.9f},
kappa>{HESSIAN['kappa_10pct_bound']:.9f}.
```

The bare zero-mode mass is `{HESSIAN['zero_mass_bare_eV']:.9f} eV`; heavy-mode
relaxation gives `{HESSIAN['zero_mass_min_eV']:.9f} eV` at the minimum and
`{HESSIAN['zero_tachyon_top_eV']:.9f} eV` tachyon magnitude at the maximum,
while all heavy modes remain stable.

## 3. Y backreaction and the conditional pin

The original `W_Y` is not rigid against the soft tower.  The nearest macro
amplitude is `eta c_X^9={NEAREST_MACRO_LOCAL_AMPLITUDE:.12e}`, giving stiffness
ratio `{Y_STIFFNESS_RATIO_KAPPA1:.6f}/kappa_Y^2`.  At `kappa_Y=1` the radial
minimum moves from `eta=0.0594612` to about `0.22328`; even `4pi` leaves a
46.7% shift.

Every `Y/P`-dressed soft harmonic therefore needs an analogous
radial-orthogonal form factor, and the benchmark adds

```text
V_Ypin=b_Y Lambda^4[1-cos(3 arg Y)], b_Y=0.1.
```

The complete canonical tower has absolute Y torque
`{Y_TORQUE:.12e} Lambda^4`, so

```text
|delta argY|<{Y_RECOIL_BOUND:.12e},
m_Yphase={Y_PHASE_MASS_GEV:.6f} GeV < 4pi Lambda.
```

This retains a three-branch wall problem and is therefore conditional.

The retained `x_0` is still external/spurionic.  A diagnostic dynamical repair,
`V_Xpin=Lambda^4[1-cos(12x)]`, gives a `{fixed_x_rows()[1]['phase_mass_GeV']:.3f}` GeV phase mass,
recoil `{fixed_x_rows()[1]['max_recoil_radian']:.6f}`, and an induced second-harmonic force near
`{100*fixed_x_rows()[1]['induced_second_harmonic_force']:.4f}%`.  It also creates twelve vacua and
is order-one continuous-clockwork breaking, so it must be sequestered or it
invalidates the operator-selection theorem.  The source coefficient itself
has discrete-R charge `-2`; aligned/sequestered R breaking is a separate gate.

## 4. Exact standard-linear no-new-field anomaly repair

For a chiral scalar of charge `R_i`, the fermion contributes `R_i-1`.  The
v1.21 fixed/global total was `11 mod 12`.  Reassign

```text
R(Sigma): 4 -> 17 mod 24.
```

Its fermion contribution changes from `3` to `16=4 mod 12`, exactly the needed
`+1`.  Sigma is neutral under the continuous clockwork selection charge and
under proton hexality, so all mixed gauge residues and the `P6` proof remain
unchanged.

{anomaly_table}

The preferred leading mass is

```text
W_Sigma = lambda_Sigma Y^2 Sigma^2/(2 Lambda),
2 R(Y)+2 R(Sigma)=16+34=50=2 mod 24,
m_Sigma=lambda_Sigma eta^2 Lambda
       ={ETA**2*LAMBDA_CW_GEV:.12f} lambda_Sigma GeV.
```

Because `R(Sigma)=17` is odd while every `P^kY^l` charge is even, no equation
`17+2k+8l=2 mod24` exists.  Thus every condensate-dressed linear Sigma tadpole
is forbidden to all orders.  An exhaustive degree-at-most-three scan of the
full listed spectrum finds zero new Sigma coupling after the common `Z2_H`.
At degree four, `B_8 PhiBar_30 Sigma^2` is also allowed but removed by the
same cell-28/cell-30 locality rule.  The condensate symmetry by itself also
permits the leading representatives `P^4Y Sigma^2` and `P^8 Sigma^2`; their
canonical mass factors are
`{P_CONDENSATE**4*ETA:.6e}` and `{P_CONDENSATE**8:.6e}`, compared with
`eta^2={ETA**2:.6e}`.  These are potentially phase-dependent thresholds.
At `Sigma=0`, any one such supersymmetric mass monomial produces no phase
potential by itself; a barrier requires interference and/or soft or
Coleman-Weinberg effects.  The P-dressed operators must therefore be removed
by a Y-only spectator locality/texture or included in an explicit threshold
bound.  The claim is limited to standard linear
mixed/gravitational congruences; nonlinear/cubic anomalies and Sigma
thresholds remain UV-sensitive.  The GS counterterm is still needed for the
visible mixed-gauge residue; Sigma repairs gravitational compatibility only.

## 5. Global and gauged moose branches

For the nearest-neighbour incidence matrix

```text
L_(j,k)=delta_(j,k)-3 delta_(j+1,k),  j=0,...,29,
```

the exact result is

```text
rank(L)=30, nullity(L)=1,
ker(L) proportional to (1,3^-1,...,3^-30).
```

This reproduces the scalar-clockwork zero mode using only order-three local
charges and gives a genuine cell/edge reason to remove the cell-28-to-cell-30
messenger shortcut.  It is consistent with the standard scalar-clockwork
mass matrix in [Giudice and McCullough](https://arxiv.org/abs/1610.07962).

{branch_table}

In the gauged-compensator branch the enlarged charge matrix has rank
`{MOOSE['compensated_rank']}` and nullity `{MOOSE['compensated_nullity']}`.
The exponent vector of `X Phi_30` is itself in its kernel with residual
`{MOOSE['local_source_residual']:.3e}` and Euclidean norm
`{MOOSE['local_source_norm']:.6f}`.  Hence the source selects a local physical
phase rather than the exponentially normalized one.  This is the scalar-source
version of the distinction between formal mass matrices and genuine clockwork
charges emphasized by [Craig et al.](https://arxiv.org/abs/1704.07831).

The product construction removes the catastrophic single-`U(1)` charge sum:

{perturb_table}

An ordinary edge is perturbative to the reduced Planck scale for `g<0.3261`.
In the stated direct vectorlike transfer, gauge invariance of the inherited
endpoint and all 17 messenger vertices forces charge-27 `Y` and charge-`3a`
messengers on the last factor, raising `b` to 5168 and requiring `g<0.02029`
up to the reduced Planck scale (`g<0.08146` for only one decade).  This value
is not universal under a distributed-link redesign.  Worse, the old
`Y^3=constant` stabilizer then ceases to be gauge invariant.

## 6. Messenger locality

With `R(Sigma)=17`, the full bilinear/cubic replay still gives

```text
17 intended + 0 unintended
```

after common `Z2_H` and the cell/edge support rule.  In particular,
`B_1 PhiBar_28 Phi_30` skips cell 29 and is excluded.  This remains conditional
on a UV geometry with no unsuppressed bridging mediator or link-dressed
nonlocal operator.  Treating shortcut leakage as consuming the remaining
force budget is a conservative contract, not yet a derived source-on harmonic
projection.  Under that contract, the remaining budget is
`{PURITY_LIMIT-HESSIAN['force_envelope_relaxed']:.12f}`.  A
two-edge hopping coefficient must therefore satisfy
`r_hop<{math.sqrt(PURITY_LIMIT-HESSIAN['force_envelope_relaxed']):.6f}`, or a
geometric realization must have
`M_gap a>{-0.5*math.log(PURITY_LIMIT-HESSIAN['force_envelope_relaxed']):.6f}`.

## 7. Gate ledger

{gate_table}

## 8. Scientific status and next falsifier

Closed in the stated benchmark:

- bounded radial-orthogonal fixed-source scalar potential;
- removal of the giant `P^4Y^2` phase barrier;
- canonical homogeneous normalization and source-on Hessian;
- 0.6207% conservative profile-relaxation stress proxy;
- standard gravitational `Z_24^R` repair through `R(Sigma)=17`;
- conditional 17+0 cell/edge messenger isolation.

Still open:

- microscopic origin/radiative stability of the non-holomorphic pins and H form factor;
- fixed-X naturalness and aligned/sequestered R=-2 soft breaking;
- Y-pin three-branch walls and radial-orthogonal tower completion;
- Y-only Sigma locality or an explicit potentially phase-dependent threshold bound;
- a gauge-invariant source that retains the exponential period;
- nonlinear/product discrete anomalies, including the stronger
  Eguchi--Hanson/spin-3/2 instanton gate, and a full GS modulus vacuum;
- link-dressed threshold portals and distributed messenger completion;
- thermal locking, odd-state relics, discrete-R walls, and cosmology.

The recommended v1.23 target is a **Wilson-line/5D-A5 or nonlocal-instanton
source audit**, because another ordinary charge scan cannot solve the gauged
local-source obstruction.  The result remains exploratory and is not evidence
for antimatter production or a confirmed physical theory.
"""


def build_one_page() -> str:
    return f"""# v1.22 one-page decision card

## Advances

- The naive cell-0/simple-A vacuum is exactly unbounded and rejected.
- Bounded fixed-X source: `V=-c_X Lambda^4 H(|Phi_30|/r) cos(theta_30+x_0)`,
  with `H(1)=1` and `H'(1)=H''(1)=0`.
- All-cell phase-blind pins pass the leading-source global bound
  `m_pin/Lambda>{PIN_MASS_BOUND_RATIO:.6f}` at the benchmark value one.
- Canonical homogeneous paired vacuum:
  `zeta_30={ZETA_30:.9f}`, `p={P_CONDENSATE:.9f}`.
- Exact frozen rigid force / profile-relaxation stress proxy:
  `{FORCE_BENCHMARK['force_leading']:.9f}` / `{HESSIAN['force_envelope_relaxed']:.9f}`;
  the conservative value is `{100*HESSIAN['force_envelope_relaxed']:.4f}%` — PASS 1%.
- Phase/stabilizer band: `{HESSIAN['heavy_phase_gap_GeV']:.3f}`--
  `{HESSIAN['heavy_phase_max_GeV']:.3f}` GeV; saxion mass `{HESSIAN['radial_gap_GeV']:.3f}` GeV.
- The original Y stabilizer fails by a stiffness ratio `{Y_STIFFNESS_RATIO_KAPPA1:.1f}`;
  the conditional `b_Y=0.1` phase pin limits recoil to `{Y_RECOIL_BOUND:.3e}` rad.
- Standard-linear no-new-field anomaly repair: `R(Sigma)=17`; total `A0=0 mod12`.
- `m_Sigma={ETA**2*LAMBDA_CW_GEV:.6f} lambda_Sigma GeV`; no `P^kY^l Sigma`
  tadpole at any order.
- Cell/edge locality: 17 intended + 0 unintended messenger terms.

## New obstruction

A gauged local moose does not inherit the fixed-source branch.  Fixed charged
`X` violates gauge invariance; dynamical `X` makes `X Phi_30` a local physical
direction with scale `{MOOSE['reduced_local_scale_GeV']:.3f} GeV`, not
`3^30 F_alpha={F_EFFECTIVE_GEV:.3e} GeV`.  The first phase-sensitive,
positive-exponent, gear-only holomorphic invariant has degree
`{MOOSE['invariant_degree']:,}` (ordinary phase-blind radial invariants can be
degree two).

## Decision

Internal checkpoint: strong EFT progress, publication **HOLD**.  Next:
gauge-invariant Wilson-line/5D-A5 or nonlocal-instanton source, followed by the
thermal/domain-wall/GS cosmology audit.
"""


def plots(out: Path, hessian_rows: list[dict], anomaly_rows: list[dict], branches: list[dict]) -> list[str]:
    names = []

    phase_masses = [row["phase_mass_GeV_source_off"] for row in hessian_rows[1:]]
    radial_masses = [row["radial_mass_GeV"] for row in hessian_rows]
    fig, ax = plt.subplots(figsize=(8.5, 5.2))
    ax.plot(range(1, len(phase_masses) + 1), phase_masses, lw=2, label="heavy phase modes")
    ax.plot(range(len(radial_masses)), radial_masses, lw=2, label="radial modes")
    ax.set_xlabel("ordered mode index")
    ax.set_ylabel("mass [GeV]")
    ax.set_title("Canonical v1.22 source-off Hessian")
    ax.grid(alpha=0.25)
    ax.legend()
    fig.tight_layout()
    name = "v1.22_hessian_spectrum.png"
    fig.savefig(out / name, dpi=180)
    plt.close(fig)
    names.append(name)

    u_values = np.linspace(0, 3, 700)
    h_values = np.array([h_profile(float(u)) for u in u_values])
    ratio_values = np.array([stability_ratio(float(u)) for u in u_values])
    fig, ax = plt.subplots(figsize=(8.2, 4.9))
    ax.plot(u_values, h_values, lw=2, label="bounded H(u)")
    ax.plot(u_values, ratio_values, lw=2, label="required $(m/\\Lambda)^2$")
    ax.axhline(1, color="black", ls="--", lw=1, label="benchmark pin")
    ax.axvline(1, color="gray", ls=":", lw=1)
    ax.set_xlabel("u = |Phi_30| / r")
    ax.set_ylabel("dimensionless")
    ax.set_title("Leading radial-orthogonal source and stability bound")
    ax.grid(alpha=0.2)
    ax.legend()
    fig.tight_layout()
    name = "v1.22_bounded_source_stability.png"
    fig.savefig(out / name, dpi=180)
    plt.close(fig)
    names.append(name)

    before = (7 + 11 + 5) % 12
    after = (before + 1) % 12
    fig, ax = plt.subplots(figsize=(7.2, 4.6))
    bars = ax.bar(["fixed/global parent", "R(Sigma)=17"], [before, after], color=["#c44e52", "#55a868"])
    ax.axhline(0, color="black", lw=1)
    ax.set_ylabel("A0 mod 12")
    ax.set_title("Standard gravitational Z24R residue")
    ax.bar_label(bars)
    fig.tight_layout()
    name = "v1.22_anomaly_repair.png"
    fig.savefig(out / name, dpi=180)
    plt.close(fig)
    names.append(name)

    labels = ["global\nfixed X", "gauged\nfixed X", "gauged\ndynamical X", "gear-only\ninvariant"]
    scores = [1, 0, 0, 0]
    colors = ["#55a868", "#c44e52", "#c44e52", "#c44e52"]
    fig, ax = plt.subplots(figsize=(8.2, 4.8))
    ax.bar(labels, scores, color=colors)
    ax.set_ylim(0, 1.15)
    ax.set_ylabel("retains inherited local amplified source")
    ax.set_title("Product/moose source decision")
    ax.set_yticks([0, 1], ["no", "conditional"])
    fig.tight_layout()
    name = "v1.22_moose_branch_decision.png"
    fig.savefig(out / name, dpi=180)
    plt.close(fig)
    names.append(name)
    return names


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--outdir", type=Path, default=Path("v1.22_release"))
    parser.add_argument("--parent-bundle", type=Path, default=None)
    args = parser.parse_args()

    out = args.outdir.resolve()
    out.mkdir(parents=True, exist_ok=True)
    script_target = out / Path(__file__).name
    if Path(__file__).resolve() != script_target:
        shutil.copy2(Path(__file__).resolve(), script_target)

    parent = parent_verification_rows(args.parent_bundle.resolve() if args.parent_bundle else None)
    if args.parent_bundle and any(row["status"] == "FAIL" for row in parent):
        raise AssertionError("v1.21 parent verification failed")

    hessian_rows = hessian_spectrum_rows()
    source_rows = source_parameter_rows()
    stability_rows = source_stability_rows()
    runaway_rows = rejected_runaway_rows()
    x_rows = fixed_x_rows()
    vacuum_rows = vacuum_operator_rows()
    sigma_rows = sigma_candidate_rows()
    anomaly_ledger = anomaly_ledger_rows()
    anomaly_repair = anomaly_repair_rows()
    sigma_tower = sigma_mass_tower_rows()
    messenger = messenger_locality_rows()
    moose_branches = moose_branch_rows()
    moose_matrix = moose_matrix_rows()
    perturb = perturbativity_rows()
    moose_r_anomaly = moose_r_anomaly_rows()
    locality = locality_contract_rows()
    gates = gate_rows(messenger)

    # Frozen and new exact assertions.
    assert abs(ZETA_30 - 0.6370331362040969) < 2e-15
    assert abs(FORCE_BENCHMARK["force_leading"] - 0.005194199756113306) < 2e-15
    assert abs(Y_TORQUE - 0.0007145653309061) < 2e-15
    assert abs(h_profile(1.0) - 1.0) < 1e-15
    assert abs(STABILITY_RATIO_MAX - 0.4777276440395) < 2e-10
    assert abs(PIN_MASS_BOUND_RATIO - 0.691178446) < 2e-8
    assert HESSIAN["phase_rank"] == 61 and HESSIAN["phase_nullity"] == 1
    assert HESSIAN["radial_rank"] == 62 and HESSIAN["radial_nullity"] == 0
    assert abs(HESSIAN["heavy_phase_gap_GeV"] - 206.63719700823356) < 1e-8
    assert abs(HESSIAN["heavy_phase_max_GeV"] - 876.1890010493187) < 1e-8
    assert abs(HESSIAN["radial_gap_GeV"] - 185.0) < 1e-8
    assert abs(HESSIAN["compliance_unit_times_Lambda2"] - 2.178439552160994) < 2e-12
    assert abs(HESSIAN["chi"] - 0.0888091226032678) < 2e-14
    assert abs(HESSIAN["force_envelope_relaxed"] - 0.00620670401709634) < 2e-14
    preferred = next(row for row in sigma_rows if row["R_Sigma"] == 17)
    assert preferred["repairs_plus1_residue"] and preferred["Y2_Sigma2_mass_allowed"]
    assert preferred["renormalizable_Sigma_terms_after_Z2H"] == 0
    assert (7 + 11 + 5 + 1) % 12 == 0
    intended_after = sum(row["intended"] and row["allowed_after_Z2H_and_locality"] for row in messenger)
    unintended_after = sum((not row["intended"]) and row["allowed_after_Z2H_and_locality"] for row in messenger)
    assert (intended_after, unintended_after) == (17, 0)
    assert MOOSE["rank"] == 30 and MOOSE["nullity"] == 1
    assert MOOSE["compensated_rank"] == 30 and MOOSE["compensated_nullity"] == 2
    assert MOOSE["local_source_residual"] == 0
    assert MOOSE["invariant_degree"] == (Q ** (N + 1) - 1) // (Q - 1)

    tables = {
        "v1.22_parent_verification.csv": parent,
        "v1.22_vacuum_operator_card.csv": vacuum_rows,
        "v1.22_source_parameters.csv": source_rows,
        "v1.22_source_stability_profile.csv": stability_rows,
        "v1.22_rejected_simple_source_runaway.csv": runaway_rows,
        "v1.22_fixed_X_branch_audit.csv": x_rows,
        "v1.22_hessian_spectrum.csv": hessian_rows,
        "v1.22_force_distance_catalog.csv": FORCE_BENCHMARK["rows"],
        "v1.22_Y_torque_by_distance.csv": Y_TORQUE_ROWS,
        "v1.22_sigma_charge_scan.csv": sigma_rows,
        "v1.22_anomaly_ledger.csv": anomaly_ledger,
        "v1.22_anomaly_repair_checks.csv": anomaly_repair,
        "v1.22_sigma_mass_tower.csv": sigma_tower,
        "v1.22_messenger_locality_audit.csv": messenger,
        "v1.22_locality_contract.csv": locality,
        "v1.22_moose_incidence_matrix.csv": moose_matrix,
        "v1.22_moose_branch_audit.csv": moose_branches,
        "v1.22_product_U1_perturbativity.csv": perturb,
        "v1.22_moose_R_anomaly_matrix_classes.csv": moose_r_anomaly,
        "v1.22_gates.csv": gates,
    }
    for name, rows in tables.items():
        write_csv(out / name, rows)

    summary = {
        "version": VERSION,
        "title": TITLE,
        "parent_sha256": EXPECTED_PARENT_SHA256,
        "epsilon": EPSILON,
        "eta": ETA,
        "c_X": C_X,
        "canonical_homogeneous_r_GeV": R_GEAR_GEV,
        "canonical_zeta_30": ZETA_30,
        "p_condensate": P_CONDENSATE,
        "fixed_X_GeV": V_X_GEV,
        "local_source_amplitude_GeV4": LOCAL_SOURCE4_GEV4,
        "projected_drive_GeV4": LOCAL_SOURCE4_GEV4 * Q**(-N),
        "H_source_at_vacuum": h_profile(1.0),
        "pin_mass_bound_over_Lambda": PIN_MASS_BOUND_RATIO,
        "pin_mass_benchmark_over_Lambda": PIN_MASS_GEV / LAMBDA_CW_GEV,
        "kappa_lock": KAPPA_LOCK,
        "effective_endpoint_period_GeV": F_EFFECTIVE_GEV,
        "bare_leading_cosine_zero_mode_mass_GeV": ZERO_MODE_MASS_GEV,
        "heavy_phase_gap_GeV": HESSIAN["heavy_phase_gap_GeV"],
        "heavy_phase_max_GeV": HESSIAN["heavy_phase_max_GeV"],
        "radial_gap_GeV": HESSIAN["radial_gap_GeV"],
        "heavy_compliance_chi": HESSIAN["chi"],
        "profile_relaxation_factor": HESSIAN["relaxation_factor"],
        "Y_torque_over_Lambda4": Y_TORQUE,
        "Y_pin_b": Y_PIN_B,
        "Y_recoil_bound_radian": Y_RECOIL_BOUND,
        "Y_phase_mass_GeV": Y_PHASE_MASS_GEV,
        "dynamical_X_pin_mass_GeV_b1": fixed_x_rows()[1]["phase_mass_GeV"],
        "dynamical_X_recoil_b1": fixed_x_rows()[1]["max_recoil_radian"],
        "exact_frozen_rigid_force": FORCE_BENCHMARK["force_leading"],
        "profile_relaxation_stress_proxy": HESSIAN["force_envelope_relaxed"],
        "force_1pct_zeta_boundary": ZETA_FORCE_BOUND,
        "preferred_R_Sigma": 17,
        "repaired_A0_total_mod12": 0,
        "Sigma_mass_GeV_unit_lambda": ETA**2 * LAMBDA_CW_GEV,
        "Sigma_P4Y_mass_factor_canonical": P_CONDENSATE**4 * ETA,
        "Sigma_P8_mass_factor_canonical": P_CONDENSATE**8,
        "messenger_locality": "17 intended + 0 unintended",
        "moose_rank": MOOSE["rank"],
        "moose_nullity": MOOSE["nullity"],
        "gauged_compensator_nullity": MOOSE["compensated_nullity"],
        "gauged_local_source_scale_GeV": MOOSE["reduced_local_scale_GeV"],
        "first_phase_sensitive_positive_exponent_gear_invariant_degree": MOOSE["invariant_degree"],
        "remaining_nonlocal_force_budget": PURITY_LIMIT - HESSIAN["force_envelope_relaxed"],
        "two_edge_hopping_bound": math.sqrt(PURITY_LIMIT - HESSIAN["force_envelope_relaxed"]),
        "geometric_gap_bound": -0.5 * math.log(PURITY_LIMIT - HESSIAN["force_envelope_relaxed"]),
        "publication_decision": "HOLD",
        "recommended_next": "gauge-invariant Wilson-line/5D-A5 or nonlocal-instanton source plus cosmology audit",
    }
    (out / "v1.22_summary.json").write_text(json.dumps(summary, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    write_csv(out / "v1.22_summary.csv", [{"quantity": key, "value": value} for key, value in summary.items()])

    note = build_note(gates, anomaly_ledger, moose_branches, perturb)
    one_page = build_one_page()
    (out / "v1.22_fixed_source_moose_anomaly_audit_note.md").write_text(note, encoding="utf-8")
    (out / "v1.22_ONE_PAGE.md").write_text(one_page, encoding="utf-8")
    readme = f"""# v1.22 reproducibility bundle

This bundle advances the verified v1.21 fixed/global branch through an
explicit fixed-source vacuum/Hessian, a no-new-field `R(Sigma)=17` standard
gravitational anomaly repair, and a global-versus-gauged product/moose audit.

## Reproduce

```text
python {Path(__file__).name} --outdir replay --parent-bundle /path/to/AM121_FULL.zip
```

The generator verifies the parent SHA and every internal parent ledger entry,
asserts the frozen force value and all new ranks/residues, writes fixed-timestamp
ZIP members, and emits its own SHA ledger.  Numerical Hessian masses refer to
the explicitly stated canonical, homogeneous, unit-coupling benchmark.

## Scope

This is an exploratory theoretical EFT checkpoint.  The standard linear
discrete-R congruence is repaired, but nonlinear/product anomalies (including
the stronger Eguchi--Hanson/spin-3/2 instanton gate), a
gauge-invariant amplified source, and cosmology remain open.
"""
    (out / "v1.22_README.md").write_text(readme, encoding="utf-8")

    plot_names = plots(out, hessian_rows, anomaly_ledger, moose_branches)

    member_names = [
        Path(__file__).name,
        *tables.keys(),
        "v1.22_summary.json",
        "v1.22_summary.csv",
        "v1.22_fixed_source_moose_anomaly_audit_note.md",
        "v1.22_ONE_PAGE.md",
        "v1.22_README.md",
        *plot_names,
    ]
    manifest_rows = []
    for name in sorted(member_names):
        path = out / name
        manifest_rows.append({"filename": name, "bytes": path.stat().st_size, "sha256": sha256(path)})
    write_csv(out / "v1.22_bundle_manifest.csv", manifest_rows)
    member_names.append("v1.22_bundle_manifest.csv")

    ledger_lines = [f"{sha256(out / name)}  {name}" for name in sorted(member_names)]
    (out / "v1.22_SHA256.txt").write_text("\n".join(ledger_lines) + "\n", encoding="utf-8")
    member_names.append("v1.22_SHA256.txt")

    bundle = out / "v1.22_fixed_source_moose_anomaly_audit_bundle.zip"
    deterministic_zip(bundle, [out / name for name in member_names])
    bundle_hash = sha256(bundle)
    (out / "v1.22_fixed_source_moose_anomaly_audit_bundle.zip.sha256").write_text(
        f"{bundle_hash}  {bundle.name}\n", encoding="utf-8"
    )
    with zipfile.ZipFile(bundle, "r") as archive:
        assert archive.testzip() is None
        assert sorted(archive.namelist()) == sorted(member_names)

    # Short-name mobile deliverables.  These are intentionally outside the
    # scientific bundle so they do not create a recursive manifest.
    complete_mobile = out / "AM122_COMPLETE.zip"
    shutil.copy2(bundle, complete_mobile)
    (out / "START.txt").write_text(one_page, encoding="utf-8")
    (out / "NOTE.txt").write_text(note, encoding="utf-8")
    (out / "SUMMARY.json").write_text(json.dumps(summary, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    shutil.copy2(out / "v1.22_gates.csv", out / "GATES.csv")
    all_in_one = out / "AM122_ALL_IN_ONE.txt"
    all_in_one.write_text(
        one_page
        + "\n\n"
        + note
        + "\n\n# MACHINE-READABLE SUMMARY\n\n"
        + json.dumps(summary, indent=2, sort_keys=True)
        + "\n",
        encoding="utf-8",
    )
    phone = out / "AM122_PHONE.zip"
    deterministic_zip(phone, [out / name for name in ("START.txt", "NOTE.txt", "SUMMARY.json", "GATES.csv")])
    with zipfile.ZipFile(phone, "r") as archive:
        assert archive.testzip() is None
    checksums = out / "AM122_CHECKSUMS.txt"
    checksums.write_text(
        "\n".join(
            f"{sha256(path)}  {path.name}"
            for path in (complete_mobile, phone, all_in_one, bundle)
        )
        + "\n",
        encoding="utf-8",
    )

    print(f"v1.22 canonical zeta_30: {ZETA_30:.12f}")
    print(f"v1.22 force envelope: {FORCE_BENCHMARK['force_leading']:.12f}")
    print(f"v1.22 repaired A0 mod12: {(7+11+5+1)%12}")
    print(f"v1.22 moose degree obstruction: {MOOSE['invariant_degree']}")
    print(f"bundle members: {len(member_names)}")
    print(f"bundle sha256: {bundle_hash}")
    print(f"phone sha256: {sha256(phone)}")


if __name__ == "__main__":
    main()
